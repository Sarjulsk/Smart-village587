# Smart Village Management System - Production Deployment

## Quick Start for Hostinger

This package contains everything you need to deploy your Smart Village Management System to Hostinger hosting.

### What's Included

- `dist/` - Production-built application files
- `package.json` - Production dependencies
- `deployment-guide.md` - Detailed step-by-step instructions
- `.env.example` - Environment variables template
- `database-schema.sql` - Database schema for reference
- `drizzle.config.ts` - Database migration configuration
- `shared/` - Shared code and schema definitions

### Quick Deployment Steps

1. **Upload Files**
   - Extract this zip to your Hostinger public_html folder
   - Ensure all files are in the root directory of your domain

2. **Set Environment Variables**
   - Copy `.env.example` to `.env`
   - Fill in your database credentials and other settings
   - In Hostinger control panel, add these same variables

3. **Install Dependencies**
   - SSH into your hosting account
   - Run: `npm install --production`

4. **Setup Database**
   - Create a database in Hostinger control panel
   - Run: `npm run db:push` to create tables
   - Or manually import the SQL schema

5. **Start Application**
   - In Hostinger Node.js settings, set startup file to: `dist/index.js`
   - Start the application

### Important Notes

- The app is built for Node.js 18+
- Default admin username: `admin` (change password after first login)
- Make sure to set a strong SESSION_SECRET
- Configure your domain SSL settings

### Need Help?

Refer to `deployment-guide.md` for detailed instructions, or contact Hostinger support for hosting-specific questions.

### Application Features

- User authentication and admin panel
- Resident management with approval system
- Event and news management
- Donation tracking and transparency
- Photo gallery with moderation
- Mobile-responsive design

Enjoy your Smart Village Management System!