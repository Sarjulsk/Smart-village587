# Hostinger Deployment Guide for Smart Village Management System

## What You'll Need Before Starting

1. **Hostinger Account** with Node.js hosting support
2. **Database Access** - Hostinger MySQL or external PostgreSQL database
3. **FTP/SSH Access** to your hosting account
4. **Domain Name** (optional but recommended)

## Step-by-Step Deployment Instructions

### Step 1: Prepare Your Database

**Option A: Use Hostinger MySQL (Recommended)**
1. Log into your Hostinger control panel
2. Go to "Databases" → "MySQL Databases"
3. Create a new database (e.g., `village_management`)
4. Note down the database credentials (host, username, password, database name)

**Option B: Use External PostgreSQL (Advanced)**
- Keep using your current Neon database
- You'll need the DATABASE_URL from your current setup

### Step 2: Configure Environment Variables

1. In your Hostinger control panel, find "Environment Variables" or "Node.js Settings"
2. Add these variables:

```
NODE_ENV=production
PORT=3000
DATABASE_URL=your_database_connection_string

# For MySQL (if using Hostinger database):
DATABASE_URL=mysql://username:password@host:port/database_name

# For PostgreSQL (if using external):
DATABASE_URL=postgresql://username:password@host:port/database_name?sslmode=require

# Optional - Google OAuth (if you want Google login):
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
GOOGLE_CALLBACK_URL=https://yourdomain.com/auth/google/callback

# Session Secret (generate a random string):
SESSION_SECRET=your_random_session_secret_here
```

### Step 3: Upload Files to Hostinger

1. **Via File Manager:**
   - Extract the deployment.zip file
   - Upload all contents to your domain's `public_html` folder
   - Make sure `package.json` and `dist/` folder are in the root

2. **Via FTP/SSH:**
   - Connect to your hosting account
   - Upload the extracted files to the correct directory
   - Ensure file permissions are set correctly

### Step 4: Install Dependencies

1. Access your hosting account's terminal/SSH
2. Navigate to your project directory
3. Run: `npm install --production`

### Step 5: Database Setup

**For MySQL:**
1. You'll need to convert the PostgreSQL schema to MySQL
2. Run the provided SQL file in your MySQL database
3. Update the database configuration in your code

**For PostgreSQL:**
1. Import the schema using: `npm run db:push` (if using Drizzle)
2. Or run the provided SQL schema file

### Step 6: Start the Application

1. In Hostinger control panel, go to "Node.js Applications"
2. Create a new application
3. Set the startup file to: `dist/index.js`
4. Set Node.js version to 18 or higher
5. Start the application

### Step 7: Domain Configuration

1. Point your domain to the Node.js application
2. Configure SSL certificate (usually automatic in Hostinger)
3. Test the application in your browser

## Important Notes

- **Database Migration**: If switching from PostgreSQL to MySQL, you'll need to update the database driver
- **File Uploads**: Configure file upload directory permissions
- **Session Storage**: The app uses database sessions, ensure your database supports this
- **Static Files**: The app serves static files from `dist/public/`

## Troubleshooting

- **Port Issues**: Hostinger typically uses port 3000 or 8080 for Node.js apps
- **Database Connection**: Check if your database credentials are correct
- **File Permissions**: Ensure uploaded files have correct read/write permissions
- **Memory Limits**: Monitor your hosting plan's memory usage

## Security Checklist

- [ ] Change SESSION_SECRET to a strong random string
- [ ] Enable HTTPS (SSL certificate)
- [ ] Configure proper CORS settings
- [ ] Set up database backups
- [ ] Enable firewall protection
- [ ] Regular security updates

## Performance Optimization

- Use Hostinger's CDN for static assets
- Enable gzip compression
- Monitor database query performance
- Set up caching if needed

For support, contact Hostinger customer service or refer to their Node.js hosting documentation.